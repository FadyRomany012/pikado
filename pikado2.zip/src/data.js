const data = {
  recordData: [
    {
      id: 1,
      imagSrc: "https://picsum.photos/200/100",
      title: " Watch and listen carefully (Title) ",
      desc: "Hi, my name is Adam and today my father is taking me a long with my sister Sara in a visit to the aquarium where we can see what life is like under the sea.",
      type: "Record",
    },
    {
      id: 2,
      imagSrc: "https://picsum.photos/200/100",
      title: " Watch and listen carefully (Title) ",
      desc: "Hi, my name is Adam and today my father is taking me a long with my sister Sara in a visit to the aquarium where we can see what life is like under the sea.",
      type: "Video",
    },
    {
      id: 3,
      imagSrc: "https://picsum.photos/200/100",
      title: " Watch and listen carefully (Title) ",
      desc: "Hi, my name is Adam and today my father is taking me a long with my sister Sara in a visit to the aquarium where we can see what life is like under the sea.",
      type: "Record",
    },
    {
      id: 4,
      imagSrc: "https://picsum.photos/200/100",
      title: " Watch and listen carefully (Title) ",
      desc: "Hi, my name is Adam and today my father is taking me a long with my sister Sara in a visit to the aquarium where we can see what life is like under the sea.",
      type: "Record",
    },
  ],
};
export default data;
